export enum ReadingStatus {
  Read = 1,
  Reading = 2,
  WantToRead = 3
}
